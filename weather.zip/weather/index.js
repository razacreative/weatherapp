console.log("this is weathor App Using JavaScript");
let fechid = document.getElementById("fechid");
fechid.addEventListener("click", () => {
    // console.log("this is Console.log");
     let showid = document.getElementById("showid").value;
     console.log(showid);
    fetch(`http://api.openweathermap.org/data/2.5/weather?q=${showid}&units=metric&zip=221001,in&APPID=fe84b801394f7d6dd87c4178079c8455`)
   
        .then( data =>{
            return data.json();
        }).then(data2 =>{
            console.log(data2.weather[0].description);
            // console.log(data2.sys[0].country);
            // this is Chack for right in console
           /*  console.log(data2);
            console.log(data2.name);
            console.log(data2.main.temp);
            console.log(data2.weather[0].description);*/
            //  this is Chack for right in console
            // <li class="list-group-item text-white bg-dark" id="name"> Zip Code <span class="badge badge-secondary">${data2.icon} </span></li>
           document.getElementById("show").innerHTML= `
                 <ul class="list-group">
            <li class="list-group-item text-white bg-dark" id="name"><i class="icon-li far fa-compass">&nbsp;</i>&nbsp;City&nbsp;<span class="badge badge-light">${data2.name}</span></li>
            <li class="list-group-item text-white bg-dark" id="tem"><i class="icon-li fas fa-temperature-low">&nbsp;</i>&nbsp;Temperature&nbsp;<span class="badge badge-light">${data2.main.temp}</span></li>
            <li class="list-group-item text-white bg-dark" id="description"><i class="icon-li fab fa-ioxhost">&nbsp;</i>&nbsp;description&nbsp;<span class="badge badge-light">${data2.weather[0].description}</span></li>
                 </ul>   `;
            // console.log(data2);
        });

});

fetch(`http://api.openweathermap.org/data/2.5/weather?q=London,uk=&units=metric&zip=94040,us, &APPID=fe84b801394f7d6dd87c4178079c8455`)

   .then( dataseco =>{
       return dataseco.json();
   }).then(data2seco =>{

       // this is Chack for right in console
      /*  console.log(data2);
       console.log(data2.name);
       console.log(data2.main.temp);
       console.log(data2.weather[0].description);*/
       //  this is Chack for right in console
       // <li class="list-group-item text-white bg-dark" id="name"> Zip Code <span class="badge badge-secondary">${data2.icon} </span></li>
      document.getElementById("secondshow").innerHTML= `
            <ul class="list-group">
       <li class="list-group-item text-white bg-dark" id="name"><i class="icon-li far fa-compass">&nbsp;</i>&nbsp;City&nbsp;<span class="badge badge-light"> ${data2seco.name} </span></li>
       <li class="list-group-item text-white bg-dark" id="description"><i class="icon-li fas fa-temperature-low">&nbsp;</i>&nbsp;Temperature&nbsp;<span class="badge badge-light"> ${data2seco.main.temp}</span></li>
       <li class="list-group-item text-white bg-dark" id="name"><i class="icon-li fab fa-ioxhost">&nbsp;</i>&nbsp;description&nbsp;<span class="badge badge-light">${data2seco.weather[0].description} </span></li>
            </ul>   `;
   });







/*console.log("this is weathor App Using JavaScript");
let fechid = document.getElementById("fechid");
fechid.addEventListener("click", () => {
   console.log("this is console.log");
   async function getItem () {
    return new Promise((res,rej)=>{
    setTimeout(() => {
        res("this is Rresovle Promise");
        
    },2000);}
    });
   }
   getItem().then(data =>{
       console.log(data);
    
});


/*console.log("this is weathor App Using JavaScript");
let fechid = document.getElementById("fechid")
fechid.addEventListener("click", async ()=>{
    console.log("this is First fechid");
return new  Promise((res,rej)=> {
console.log("this nis Retun Promise");
   

   })
})*/

 







